import cv2
import numpy as np

class box():
    def find_pixels(self,image):
	
	# find the contours in the edged image and keep the largest one;
	# we'll assume that this is our piece of paper in the image
        im,cnts, hie = cv2.findContours(image.copy(), cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)
        
        c = max(cnts, key = cv2.contourArea)
 
	# compute the bounding box of the of the paper region and return it
        return cv2.minAreaRect(c)

    
    def distance_to_camera(self,knownWidth, focalLength, perWidth):
	# compute and return the distance from the maker to the camera
        try:
            return (knownWidth * focalLength) / perWidth
        
        except ZeroDivisionError:
            return 0

    def canny(self,x):
        #fliter to a
        image = cv2.resize(x,(500,500))
        img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        img_blur = cv2.GaussianBlur(img_gray,(5,5),0)
        img_edge = cv2.Canny(img_blur,35,125)
        return img_edge

    def clean(self,x):
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
        closed = cv2.morphologyEx(x, cv2.MORPH_CLOSE, kernel)
        return closed

    def drawBox(self,frame,cx,cy,app,inches):
        
        cv2.drawContours(frame, [app],-1,(255,255,0),4)
        cv2.circle(frame,(cx,cy),7,(255,255,255),-1)
        cv2.putText(frame,"center"+ str((cx, cy)),(cx-20, cy-20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
        cv2.putText(frame, "%.2fft" % (inches / 12),
		(frame.shape[1] - 300, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
		2.0, (0, 255, 0), 3)
        return frame

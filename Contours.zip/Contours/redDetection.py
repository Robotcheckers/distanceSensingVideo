import cv2
import numpy as np

cap = cv2.VideoCapture(0)
image = cv2.imread('redSquare2ft.jpg')
image = cv2.resize(image,(500,500))
hsv_img = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
lower_red_img=np.array([150,150,30])
upper_red_img=np.array([180,255,255])
mask_img = cv2.inRange(hsv_img,lower_red_img,upper_red_img)
res_img = cv2.bitwise_and(image,image, mask_img)
canny_img = cv2.Canny(res_img,200,250)
cv2.imshow('picture', canny_img)

while True:
    ret,frame = cap.read()

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    lower_red=np.array([150,150,30])
    upper_red=np.array([180,255,255])

    mask = cv2.inRange(hsv,lower_red,upper_red)
    res = cv2.bitwise_and(frame,frame, mask = mask)
    blur = cv2.GaussianBlur(res,(5,5),0)
    kernel = np.ones((5,5), np.uint8)
    closed = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    
   
    
    #cv2.imshow('closed',closed)
    

    #cv2.imshow('blur',blur)
    
    if cv2.waitKey(1) &0xFF == ord('q'):
        break

cv2.destroyAllWindows()
cap.release()

import cv2
import numpy as np


def find_pixels(image):
	
	# find the contours in the edged image and keep the largest one;
	# we'll assume that this is our piece of paper in the image
        im,cnts, hie = cv2.findContours(image.copy(), cv2.RETR_LIST,
                                        cv2.CHAIN_APPROX_SIMPLE)
        
        c = max(cnts, key = cv2.contourArea)
 
	# compute the bounding box of the of the paper region and return it
        return cv2.minAreaRect(c)

def distance_to_camera(knownWidth, focalLength, perWidth):
	# compute and return the distance from the maker to the camera
        try:
            return (knownWidth * focalLength) / perWidth
        
        except ZeroDivisionError:
            return 0

def canny(x):
        #fliter to a
        image = cv2.resize(x,(500,500))
        hsv_img = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        lower_red_img=np.array([150,150,30])
        upper_red_img=np.array([180,255,255])
        mask_img = cv2.inRange(hsv_img,lower_red_img,upper_red_img)
        res_img = cv2.bitwise_and(image,image, mask_img)
        canny_img = cv2.Canny(res_img,200,250)
        return canny_img

#known distance is at 12 inches
#known width is 2 inches
know_distance = 24.0
known_width = 3.0



#this picture is our reference point
#this is where we find the apparent focal length

image = cv2.imread('redSquare2ft.jpg')


img_edge = canny(image)
#cv2.imshow('2 feet away', img_edge)
pixels = find_pixels(img_edge)
focalLength = (pixels[1][0] * know_distance) / known_width

#prints out the pixels and focal length from that distance
print ('focal length',focalLength)
#now since we have the focal legnth
#we can use D' = (Known width * focal length)/Pixel
cap = cv2.VideoCapture(0)
while True:
    ret,frame = cap.read()
    frame = cv2.resize(frame,(500,500))
    #HSV and fliter out for red
    #these are the upper and lower for red
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red=np.array([150,150,30])
    upper_red=np.array([180,255,255])
    mask = cv2.inRange(hsv,lower_red,upper_red)
    res = cv2.bitwise_and(frame,frame, mask = mask)
    #detects edges in video
    edge = cv2.Canny(res,10,250)

    #clean noise and close gaps between white
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
    closed = cv2.morphologyEx(edge, cv2.MORPH_CLOSE, kernel)
        
    #find contours in the video
    im,cnts, hie=cv2.findContours(closed.copy(),
                                  cv2.RETR_LIST,
                                  cv2.CHAIN_APPROX_SIMPLE)
    try:
        cnt = cnts[0]
    except IndexError:
        cnt = 1
  
    
    #loop over the contours in the video
    for c in cnts:
        
        #find the pixels in the video
        cap_pix = find_pixels(edge)
        inches = distance_to_camera(known_width, focalLength,cap_pix[1][0])
        
        #approximate the number of dots in the video
        M = cv2.moments(cnt)
        peri = cv2.arcLength(c,True)
        app = cv2.approxPolyDP(c,0.02 * peri, True)
        
        #if approximate contour has four points,
        #then assume it is a rectangle
        if len(app) == 4:
            #try and except are the safety just incase no rectangles are found
            try:
                cx = int(M["m10"] / M["m00"])
                cy = int(M["m01"] / M["m00"])
            except ZeroDivisionError:
                cx = 0
                cy = 0
            #Draw a box around the rectangle along with the center and the centers location
            cv2.drawContours(frame, [app],-1,(255,255,0),4)
            cv2.circle(frame,(cx,cy),7,(255,255,255),-1)
            cv2.putText(frame,"center"+ str((cx, cy)),(cx-20, cy-20),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
            cv2.putText(frame, "%.2fft" % (inches / 12),
		(frame.shape[1] - 300, frame.shape[0] - 20), cv2.FONT_HERSHEY_SIMPLEX,
		2.0, (0, 255, 0), 3)
            print('ft away',(inches/12))
    cv2.imshow('Rectangles',frame)
    if cv2.waitKey(1) &0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
